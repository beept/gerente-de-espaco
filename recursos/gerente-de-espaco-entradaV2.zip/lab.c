#include <stdio.h>
#include <string.h>

typedef enum
{
	true = 1,
	false = 0,
} bool;

int main()
{
	FILE *input = fopen("entrada_dados.txt", "r");
	if (input != NULL)
	{
		FILE *output = fopen("resultado.txt", "w");

		if (output != NULL)
		{
			bool falhaInsercao = false;
			char operacao[8];
			char nomeArq[11];
			char buff[25] = "";
			char un;

			int pass;
			int maxOperacao;
			int tamanho;

			fscanf(input, "%d", &maxOperacao);
			fprintf(output, "%d", maxOperacao);

			while (maxOperacao)
			{
				fscanf(input, "%d%cB", &tamanho, &un);
				fprintf(output, "\n%d%cB", tamanho, un);

				while (maxOperacao)
				{
					fscanf(input, "%s %s", &operacao, &nomeArq);
					fprintf(output, "\n%s %s", operacao, nomeArq);

					if (!strcmp(operacao, "insere"))
					{
						fscanf(input, "%d%cB", &tamanho, &un);
						fprintf(output, " %d%cB", tamanho, un);
					}
					else if (!strcmp(operacao, "remove"))
						pass = 1;

					maxOperacao--;
				}

				fscanf(input, "%d", &maxOperacao);
				fprintf(output, "\n%d", maxOperacao);
			}
			fprintf(output, "%c", '\n');
			fclose(output);
		}
		else
			perror("ErroMsg");
		fclose(input);
	}
	else
		perror("ErroMsg");
	return 0;
}
